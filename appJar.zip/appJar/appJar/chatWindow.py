import sys
import time
sys.path.append("../../")
from appJar import gui
sys.path.append("")
class chatWin:
	app = gui("Login Window", "400x400")
	def openWindow():
		app.setBg("orange")
		app.setFont(14)
		app.addEntry("chat")
		app.addButton("Print:")
		app.go()