import sys
import time
sys.path.append("../../")
from appJar import gui
from chatWindow import chatWin


from ClientServer import ClientServer
from M2Crypto import RSA 
from ServerConnection import ServerConnection
from random import randint
from P2PChat import P2PChat


app = gui("Login Window", "400x200")
app.setBg("orange")
app.setFont(18)


def isNotRegistered(username):
	with open('users.d','r') as f:
		return re.search('{'+username+';([a-z|0-9]+)}\n',f.read()) == None

def checkUsername(username):	
	notRegistered = isNotRegistered(username)
	if(notRegistered == True):
		if(app.yesNoBox("Register", "The username you chose isn't registered. \nWould you like to register it?") == False):
			return False
	rsa = RSA.load_pub_key('keys/key.pem')
	c=ClientServer(ServerConnection('127.0.0.1',5000,None,rsa),username,not notRegistered)
	return True

def press(button):
    if button == "Cancel":
        app.stop()
    else:
        usr = app.getEntry("Username")
        if(checkUsername(usr)):
			window = openChatWindow()
			window.openWindow()
			app.stop()
		
app.addEntry("Username")
app.addLabel("Choose","Choose one of the following choices:")
app.addButtons(["Submit", "Cancel"], press)
app.go()
